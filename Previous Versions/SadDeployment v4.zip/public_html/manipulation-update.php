<!Doctype html>
<html>
	<head>
		<meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
		<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0"> 
		<link rel="stylesheet" type="text/css" href="css/admin.css">
		<link rel="stylesheet" href="css/font-awesome.min.css">
		<link rel="stylesheet" href="css/bootstrap.min.css">
		

		<title>StockEye</title>
		
	</head>
	<body>
	<!--header-->
		<div class="container-fluid" id="header">
			<span style="float:right; font-size:15px; margin:2px; color:white;">
                Hi, <strong>
                    <?php 
						session_start();
						echo $_SESSION["EmpName"]; 
						?> 
                   </strong>
                     <a href="logout.php"><input class="btn btn-primary" type="button" value="Logout"></a>
                </span>
		</div>
	<!--header-->

	<!--navbar-->
		<div class="container-fluid" id="navbar">
		<ul class="nav nav-pills nav-justified">
			<li role="presentation"><a href='overview.php'>Overview</a></li>
			<li role="presentation" class="active"><a href='manipulation.php'>Manipulation</a></li>
			<li role="presentation"><a href='pendingrequests.php'>Requests</a></li>
			<li role="presentation"><a href='monitoring.php'>Monitoring</a></li>
			<li role="presentation"><a href='itemreq.php'>Item Request</a></li>
			<li role="presentation"><a href='admin-overview.php'>Admin Tools</a></li>
		</ul>
		</div>
	<!--navbar-->

	<!--tool body--><!--OK SENPAI!-->
		<div class="container-fluid" id="tools">
			<ul class="nav nav-tabs">
			<li role="presentation"><a href='manipulation-add.php'>Add Item</a></li>
			<li role="presentation"><a href='manipulation-remove.php'>Remove Item</a></li>
			<li role="presentation" class="active"><a href='manipulation-update.php'>Update Item</a></li>

			</ul>

			<div class="input-group panel panel-default" id="formfield">
			<form>
				<h3> Update Item</h3>
				
  				<input type="text" class="form-control" placeholder="Item ID">
  				<input type="text" class="form-control" placeholder="Quantity">
  				<span id="buttons"><button type="submit" class="btn btn-primary">Update</button></span>

			</form>
			</div>

		</div>
		<!--tool body-->
		<script src="js/jquery-2.1.4.min.js"></script>

		<script src="js/bootstrap.min.js"></script>

	
	
	</body>
	</html>