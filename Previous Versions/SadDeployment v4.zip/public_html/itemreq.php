<!Doctype html>
<html>
	<head>
		<meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
		<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0"> 
		<link rel="stylesheet" type="text/css" href="css/admin.css">
		<link rel="stylesheet" href="css/font-awesome.min.css">
		<link rel="stylesheet" href="css/bootstrap.min.css">
<title>Item Request</title>
<head>
<div class="container-fluid" id="header">
		<span style="float:right; font-size:15px; margin:2px; color:white;">
                Hi, <strong>
                    <?php 
						session_start();
						echo $_SESSION["EmpName"]; 
						?> 
                   </strong>
                     <a href="logout.php"><input class="btn btn-primary" type="button" value="Logout"></a>
                </span>
</div>
		<div class="container-fluid" id="navbar">
		<ul class="nav nav-pills nav-justified">
			<li role="presentation"><a href='overview.php'>Overview</a></li>
			<li role="presentation"><a href='manipulation.php'>Manipulation</a></li>
			<li role="presentation"><a href='pendingrequests.php'>Requests</a></li>
			<li role="presentation"><a href='monitoring.php'>Monitoring</a></li>
			<li role="presentation" class="active"><a href='itemreq.php'>Item Request</a></li>
			<li role="presentation"><a href='admin-overview.php'>Admin Tools</a></li>
		</ul>

		</div>
			</ul>

			<div class="input-group panel panel-default" id="formfield">
			<form>
				<h3>Input Item Requested</h3>
				
  				<input type="text" class="form-control" placeholder="Item Name">
  				<input type="password" class="form-control" placeholder="Amount">
  				<input type="text" class="form-control" placeholder="Requestee">
  				<span id="buttons"><button type="submit" class="btn btn-primary">Submit</button></span>

			</form>
			</div>

		<script src="js/jquery-2.1.4.min.js"></script>

		<script src="js/bootstrap.min.js"></script>
</body>
</html>