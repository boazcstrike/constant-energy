<?php
	class Success{
	
		function getSuccess($successnumber){
			if($successnumber == 2){
				echo "<div class='alert alert-success' style='position:absolute; top:60%; left:41.11%'> 
							<b>Successfully</b> Disabled an account.
							&nbsp;&nbsp;&nbsp;<button type = 'button' class = 'close' data-dismiss = 'alert'> &times;</button>
							</div>";
			}else if( $successnumber == 1 ){
				echo "<div class='alert alert-success' style='position:absolute; top:70%; left:42%'> 
					<b>Successfully</b> added an account.
					&nbsp;&nbsp;&nbsp;<button type = 'button' class = 'close' data-dismiss = 'alert'> &times;</button>
					</div>";
			}
		
		}
	
	}
	
	$successHandler = new Success;

?>