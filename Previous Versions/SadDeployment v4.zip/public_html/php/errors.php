<?php
	 class Error{
		
		public function getE($errornumber){
				if($errornumber == 1){
				echo "<div class='alert alert-danger' style='position:absolute; top:60%; left:41.5%'> 
					      <b>Uhh oh!</b> Please enter username.
					      &nbsp;&nbsp;&nbsp;<button type = 'button' class = 'close' data-dismiss = 'alert'> &times;</button>
					      </div>";
				} else if($errornumber == 2){
			     echo "<div class='alert alert-danger' style='position:absolute; top:60%; left:42.2%'> 
				        <b>Oops!</b> User already disabled.
						 &nbsp;&nbsp;&nbsp;<button type = 'button' class = 'close' data-dismiss = 'alert'> &times;</button>
						 </div>";
				}else if($errornumber == 3){
				echo "<div class='alert alert-danger' style='position:absolute; top:60%; left:42.5%'> 
						 <b>Woops!</b> User does not exist.
						 &nbsp;&nbsp;&nbsp;<button type = 'button' class = 'close' data-dismiss = 'alert'> &times;</button>
						 </div>";
				}else if($errornumber == 4){
				echo "<div class='alert alert-danger' style='position:absolute; top:70%; left:39.5%'> 
						 <b>Uhh oh!</b> Please fill up all information needed.
						 &nbsp;&nbsp;&nbsp;<button type = 'button' class = 'close' data-dismiss = 'alert'> &times;</button>
						 </div>";
				}else if($errornumber == 5){
				echo "<div class='alert alert-danger' style='position:absolute; top:70%; left:42.5%'> 
						 <b>Woops!</b> User already exist.
						 &nbsp;&nbsp;&nbsp;<button type = 'button' class = 'close' data-dismiss = 'alert'> &times;</button>
						 </div>";
				}
			}
			
		
			
	}
	
	
	$errorHandler = new Error;
	 
	 

?>