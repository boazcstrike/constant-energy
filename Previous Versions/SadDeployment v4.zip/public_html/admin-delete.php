<!Doctype html>
<html>
	<head>
		<meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
		<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0"> 
		<link rel="stylesheet" type="text/css" href="css/admin.css">
		<link rel="stylesheet" href="css/font-awesome.min.css">
		<link rel="stylesheet" href="css/bootstrap.min.css">
		

		<title>StockEye</title>
		
	</head>
	<body>
		<div class="container-fluid" id="header">
			<span style="float:right; font-size:15px; margin:2px; color:white;">
                Hi, <strong>
                    <?php 
						session_start();
						echo $_SESSION["EmpName"]; 
						?> 
                   </strong>
                     <a href="logout.php"><input class="btn btn-primary" type="button" value="Logout"></a>
                </span>
		</div>
		<div class="container-fluid" id="navbar">
		<ul class="nav nav-pills nav-justified">
			<li role="presentation"><a href='overview.php'>Overview</a></li>
			<li role="presentation"><a href='manipulation.php'>Manipulation</a></li>
			<li role="presentation"><a href='pendingrequests.php'>Requests</a></li>
			<li role="presentation"><a href='monitoring.php'>Monitoring</a></li>
			<li role="presentation"><a href='itemreq.php'>Item Request</a></li>
			<li role="presentation" class="active"><a href='#'>Admin Tools</a></li>
		</ul>

			
		</div>

		<div class="container-fluid" id="tools">
			<ul class="nav nav-tabs">
			<li role="presentation"><a href='admin-add.php'>Add Account</a></li>
			<li role="presentation" class="active"><a href='#'>Disable Account</a></li>
			<li role="presentation"><a href='admin-overview.php'>Accounts Overview</a></li>


			</ul>

			<div class="input-group panel panel-default" id="formfield">
			<form action = "php/disable.php" method = "post">
				<h3> Disable</h3>
				
  				<input type="text" name="uname" class="form-control" placeholder="Username">
  				
  				<span id="buttons"><button type="submit" class="btn btn-primary">Disable</button></span>

			</form>
			</div>
		<?php 	if(isset($_GET["error"])){
						if($_GET["error"] == 1){
						echo "<div class='alert alert-danger' style='position:absolute; top:60%; left:41.5%'> 
						 <b>Uhh oh!</b> Please enter username.
						 &nbsp;&nbsp;&nbsp;<button type = 'button' class = 'close' data-dismiss = 'alert'> &times;</button>
						 </div>";
						}else if($_GET["error"] == 2){
						echo "<div class='alert alert-danger' style='position:absolute; top:60%; left:42.2%'> 
						 <b>Oops!</b> User already disabled.
						 &nbsp;&nbsp;&nbsp;<button type = 'button' class = 'close' data-dismiss = 'alert'> &times;</button>
						 </div>";
						}else if($_GET["error"] == 3){
						echo "<div class='alert alert-danger' style='position:absolute; top:60%; left:42.5%'> 
						 <b>Woops!</b> User does not exist.
						 &nbsp;&nbsp;&nbsp;<button type = 'button' class = 'close' data-dismiss = 'alert'> &times;</button>
						 </div>";
						}
					}
			
					if(isset($_GET["success"])){
					echo "<div class='alert alert-success' style='position:absolute; top:60%; left:41.11%'> 
						 <b>Successfully</b> Disabled an account.
						 &nbsp;&nbsp;&nbsp;<button type = 'button' class = 'close' data-dismiss = 'alert'> &times;</button>
						 </div>";
					}
			?>

		</div>

		<script src="js/jquery-2.1.4.min.js"></script>

		<script src="js/bootstrap.min.js"></script>

	
	
	</body>
	</html>


