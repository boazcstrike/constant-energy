<?php

$DBuser="root";
$DBpass="";
$Database="sad_database";
$DBurl="localhost";

?>