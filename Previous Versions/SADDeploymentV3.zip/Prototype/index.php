<!Doctype html>
<html>
	<head>
		<meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
		<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0"> 
		<link rel="stylesheet" type="text/css" href="css/login.css">
		<link rel="stylesheet" href="css/font-awesome.min.css">
		<link rel="stylesheet" href="css/bootstrap.min.css">
		

		<title>StockEye</title>
		
	</head>
	<body>
		<div class="container-fluid" id="header">


		</div>

		<div class="container-fluid" id="formcontainer">

			<div id="form">
			<form action="authentication.php" method="POST">
			<center><h3><span class="label label-info">Welcome to Stockeye</span></h3></center>

			
			<div class="input-group">
				<span class="input-group-addon" id="basic-addon1">Username</span>
				<input type="text" name="username" class="form-control" placeholder="Type your username">



				</div>
			<div class="input-group">
				<span class="input-group-addon" id="basic-addon1">Password</span>
				<input type="password" name="password" class="form-control">
				</div>

			<div class="input-group">
				<input type="submit" class="btn btn-primary" value="Log in">
				</div>
			<?php 
			session_start();
			
			if (isset($_GET['error'])){
				 echo "<div class='alert alert-danger' role='alert'><strong>Try Again. </strong> Username or Password incorrect.</div>";
				 } 
				 ?>
				</div>
			</div>
		</div>
		</form>
		<div class="container-fluid" id="footer">
		
		



		</div>
		
			
				


			<script src="js/jquery-2.1.4.min.js"></script>
			
			<script src="js/bootstrap.min.js"></script>
	</body>
</html>