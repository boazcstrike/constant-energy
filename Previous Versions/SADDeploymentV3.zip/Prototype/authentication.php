<html>
<head><title>Logging in</title></head>
<body>
	<?php
		session_start();
		
		$username= $_POST["username"];
		$password= $_POST["password"];
		
		if($username == null || $password == null){
			header("Location: index.php?error=1");
		}else{
		
		//Connecting
		include("config.php");
		include("dbconnect.php");
		}
		
		
		
		
	?>
</body>
</html>