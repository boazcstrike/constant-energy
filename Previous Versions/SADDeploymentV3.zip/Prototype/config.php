<?php

$DBuser="stockeye";
$DBpass="2012043676 BOAZCSTRIKe";
$Database="stockeye_test";
$DBurl="localhost";
?>