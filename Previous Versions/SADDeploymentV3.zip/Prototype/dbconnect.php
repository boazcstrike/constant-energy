<?php
			
		$connection = mysql_connect($DBurl,$DBuser,$DBpass);
		
		if($connection==true){
			echo "connected";
		}else{
			die("<b>Disconected</b> " . mysql_error());
		}
		
		$database = mysql_query('use logdatabase;');
			if(!$database){
				die('No database' . mysql_error());
			}else{
				echo("$database database selected<br>");
			}
			
		$check = mysql_query("SELECT * FROM users WHERE username = '$username';");   
			echo $check;
		
		
		while($results = mysql_fetch_array($check)){
			
			
			if($results['Pass']==$_POST['password']&&$results['Username']==$_POST['username']){
	
				header("Location: home.html");
				break;
			}else{
				header("Location: index.php?error=1");
			}
		
		}
		
		
		
		
?>